"""Keyword search over backend/docs/*.md and *.txt. No vector database."""
import re
from pathlib import Path

DOCS_DIR = Path(__file__).resolve().parents[2] / "docs"
STOP = {"the", "and", "for", "why", "what", "how", "does", "are", "is", "of", "to", "a", "in",
        "on", "it", "with", "this", "that", "can", "do", "we", "our", "about", "from", "hard"}


def _stem(w: str) -> str:
    return w[:5] if len(w) > 5 else w


def _tokens(text: str) -> list[str]:
    return [_stem(w) for w in re.findall(r"[a-z0-9]+", text.lower()) if len(w) > 2 and w not in STOP]


def _is_heading(line: str, prev_blank: bool) -> str | None:
    s = line.strip()
    if s.startswith("#"):
        return s.lstrip("#").strip()
    if prev_blank and 0 < len(s) <= 70 and s[-1] not in ".,;!?" and not s.startswith(("-", "*")):
        return s.rstrip(":")
    return None


def load_paragraphs() -> list[dict]:
    items = []
    for path in sorted(DOCS_DIR.glob("*")):
        if path.suffix.lower() not in {".md", ".txt"}:
            continue
        heading, buf, prev_blank = "(no heading)", [], True
        def flush():
            if buf:
                items.append({"file": path.name, "section": heading, "text": " ".join(buf).strip()})
                buf.clear()
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                flush(); prev_blank = True; continue
            h = _is_heading(line, prev_blank)
            if h is not None and (line.strip().startswith("#") or not buf):
                flush(); heading = h
            else:
                buf.append(line.strip())
            prev_blank = False
        flush()
    return items


def search(query: str, k: int = 3) -> list[dict]:
    q = set(_tokens(query))
    if not q:
        return []
    scored = []
    for p in load_paragraphs():
        toks = _tokens(p["text"])
        head = set(_tokens(p["section"]))
        score = sum(min(toks.count(t), 3) for t in q) + 2 * len(q & head)
        if score > 0:
            scored.append((score, p))
    scored.sort(key=lambda t: -t[0])
    return [{"file": p["file"], "section": p["section"], "text": p["text"][:700], "score": s}
            for s, p in scored[:k]]
