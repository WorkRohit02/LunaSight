<!-- PLACEHOLDER: replace this file with the real LunaSight roadmap. -->
# LunaSight roadmap

## Why the south pole is hard to power
Sunlight reaches the lunar south pole at a very low angle. Crater rims can be lit for long periods, but nearby terrain casts long shadows, so the same spot can swing between light and darkness. Solar arrays need steady light, so a lander has to plan around the periods when the site is dark.

## Communications with Earth
From the south pole, Earth sits low near the horizon. Terrain can block the line of sight, which creates communications blackouts that vary by site and by date.

## Planned features
The first release compares candidate sites and dates using the science engine. Later releases add side-by-side delay scenarios for mission planning.
