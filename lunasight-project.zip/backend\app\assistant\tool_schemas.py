LOCATION_PROPS = {
    "site_name": {"type": "string", "description": "A preset site name such as 'Shackleton Rim'. Use this OR latitude+longitude."},
    "latitude": {"type": "number", "description": "Latitude in degrees (south is negative)."},
    "longitude": {"type": "number", "description": "Longitude in degrees."},
}

TOOL_SCHEMAS = [
    {"type": "function", "function": {
        "name": "get_site_analysis",
        "description": "Estimate sunlit hours, longest darkness, Earth-visible hours and longest communications blackout for a landing site over a time window.",
        "parameters": {"type": "object", "properties": {
            **LOCATION_PROPS,
            "start_time": {"type": "string", "description": "ISO 8601 UTC start, e.g. 2027-01-15T00:00:00Z"},
            "duration_hours": {"type": "number", "description": "Window length in hours. Default 24."},
        }, "required": ["start_time"]}}},
    {"type": "function", "function": {
        "name": "run_delay_scenario",
        "description": "Compare a landing at the original start time with the same landing delayed by 1 day, 7 days or 29.5 days (one lunar cycle). Runs the analysis twice and returns both results and the differences.",
        "parameters": {"type": "object", "properties": {
            **LOCATION_PROPS,
            "original_start_time": {"type": "string", "description": "ISO 8601 UTC original start."},
            "delay_days": {"type": "number", "enum": [1, 7, 29.5], "description": "Delay in days."},
            "duration_hours": {"type": "number", "description": "Window length in hours. Default 24."},
        }, "required": ["original_start_time", "delay_days"]}}},
    {"type": "function", "function": {
        "name": "search_docs",
        "description": "Keyword search over the LunaSight project documents (roadmap, problem statement). Use for any project or background question.",
        "parameters": {"type": "object", "properties": {
            "query": {"type": "string", "description": "Keywords to search for."},
        }, "required": ["query"]}}},
]
