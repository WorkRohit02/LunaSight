import json
import os
from typing import Literal

import httpx
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from .prompts import system_prompt
from .providers import call_llm_with_fallback
from .tool_schemas import TOOL_SCHEMAS
from .tools import run_tool

router = APIRouter()
MAX_ROUNDS = 5


class HistoryItem(BaseModel):
    role: Literal["user", "assistant"]
    content: str


class ChatRequest(BaseModel):
    message: str
    history: list[HistoryItem] = []
    mode: Literal["planner", "educator"] = "planner"


class ToolCallInfo(BaseModel):
    name: str
    arguments: dict


class ChatResponse(BaseModel):
    reply: str
    tool_calls: list[ToolCallInfo]
    provider: str | None = None


async def call_llm(messages: list[dict], allow_tools: bool = True) -> dict:
    return await call_llm_with_fallback(messages, allow_tools)


@router.post("/chat", response_model=ChatResponse)
async def chat(req: ChatRequest) -> ChatResponse:
    messages = [{"role": "system", "content": system_prompt(req.mode)}]
    messages += [h.model_dump() for h in req.history]
    messages.append({"role": "user", "content": req.message})
    used: list[ToolCallInfo] = []

    for _ in range(MAX_ROUNDS):
        msg = await call_llm(messages)
        calls = msg.get("tool_calls")
        if not calls:
            return ChatResponse(reply=msg.get("content") or "", tool_calls=used, provider=msg.get("_provider"))
        messages.append({"role": "assistant", "content": msg.get("content") or "", "tool_calls": calls})
        for tc in calls:
            name = tc["function"]["name"]
            try:
                args = json.loads(tc["function"].get("arguments") or "{}")
            except json.JSONDecodeError:
                args = None
            result = await run_tool(name, args) if args is not None else {"error": "Tool arguments were not valid JSON."}
            used.append(ToolCallInfo(name=name, arguments=args if isinstance(args, dict) else {}))
            messages.append({"role": "tool", "tool_call_id": tc["id"], "content": json.dumps(result)})

    # Round cap reached: force a final answer from what the tools returned.
    msg = await call_llm(messages, allow_tools=False)
    return ChatResponse(reply=msg.get("content") or "", tool_calls=used, provider=msg.get("_provider"))
