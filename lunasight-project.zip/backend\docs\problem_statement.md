<!-- PLACEHOLDER: replace this file with the real LunaSight problem statement. -->
# LunaSight problem statement

## Problem
Teams choosing a lunar south-pole landing site and date need to understand lighting and Earth visibility. Today this takes specialist tools, which makes it hard for learners and educators to explore the trade-offs.

## What LunaSight does not cover
LunaSight does not assess boulder hazards, radio link budgets, landing safety certification, or rover route planning.
