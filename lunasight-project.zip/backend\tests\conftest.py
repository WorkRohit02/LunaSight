import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
# Assistant tests mock the engine over HTTP, so use the external-engine path.
os.environ["USE_EXTERNAL_ENGINE"] = "1"
os.environ["SCIENCE_ENGINE_URL"] = "http://localhost:8001"
os.environ["LLM_RETRY_DELAY"] = "0"
