"""Offline tests: the science engine is mocked with respx and the LLM is faked.
They check the plumbing (tool calls, error handling, the 5-round cap), not Grok's wording."""
import asyncio, json
import httpx, respx
from fastapi.testclient import TestClient

from main import app
from app.assistant import chat as chat_mod
from app.assistant.providers import call_llm_with_fallback, ProviderConfig
from app.assistant.tools import get_site_analysis, run_delay_scenario, search_docs

ENGINE = "http://localhost:8001/analysis/full"


def engine_ok(request):
    start = json.loads(request.content)["start_time"]
    base = 10.0 if start.startswith("2027-01-15") else 12.5
    return httpx.Response(200, json={"sunlit_hours": base, "longest_darkness_hours": 3.0,
                                     "earth_visible_hours": 20.0, "longest_blackout_hours": base / 5})


@respx.mock
def test_site_analysis_returns_engine_numbers():
    respx.post(ENGINE).mock(side_effect=engine_ok)
    r = asyncio.run(get_site_analysis(site_name="Shackleton Rim", start_time="2027-01-15T00:00Z"))
    assert r["sunlit_hours"] == 10.0 and r["estimate"] is True and "error" not in r


@respx.mock
def test_delay_scenario_calls_engine_twice_and_diffs():
    route = respx.post(ENGINE).mock(side_effect=engine_ok)
    r = asyncio.run(run_delay_scenario(site_name="Shackleton Rim", original_start_time="2027-01-15T00:00:00Z", delay_days=7))
    assert route.call_count == 2
    assert r["original"]["sunlit_hours"] == 10.0 and r["delayed"]["sunlit_hours"] == 12.5
    assert r["differences"]["change_sunlit_hours"] == 2.5
    assert r["delayed"]["start_time"] == "2027-01-22T00:00:00Z"


def test_bad_delay_and_missing_location_are_errors_not_exceptions():
    assert "error" in asyncio.run(run_delay_scenario(site_name="X", original_start_time="2027-01-15T00:00:00Z", delay_days=3))
    assert "error" in asyncio.run(get_site_analysis(start_time="2027-01-15T00:00:00Z"))
    assert "error" in asyncio.run(get_site_analysis(site_name="X", start_time="not a date"))


@respx.mock
def test_engine_down_returns_error():
    respx.post(ENGINE).mock(side_effect=httpx.ConnectError("down"))
    r = asyncio.run(get_site_analysis(site_name="Shackleton Rim", start_time="2027-01-15T00:00:00Z"))
    assert "error" in r and "science engine" in r["error"].lower()


def test_docs_search_finds_power_section():
    r = asyncio.run(search_docs(query="Why is the south pole hard to power?"))
    top = r["results"][0]
    assert top["file"] == "roadmap.md" and "power" in top["section"].lower()


def test_chat_loop_runs_tools_and_caps_rounds(monkeypatch):
    calls = {"n": 0}
    async def fake_llm(messages, allow_tools=True):
        calls["n"] += 1
        if not allow_tools:
            return {"content": "final answer"}
        return {"content": "", "tool_calls": [{"id": f"c{calls['n']}", "type": "function",
                "function": {"name": "search_docs", "arguments": json.dumps({"query": "power"})}}]}
    monkeypatch.setattr(chat_mod, "call_llm", fake_llm)
    res = TestClient(app).post("/api/chat", json={"message": "hi", "history": [], "mode": "planner"}).json()
    assert res["reply"] == "final answer"
    assert len(res["tool_calls"]) == chat_mod.MAX_ROUNDS and calls["n"] == chat_mod.MAX_ROUNDS + 1


@respx.mock
def test_llm_fallback_switches_to_gemini_when_xai_fails(monkeypatch):
    monkeypatch.setenv("XAI_API_KEY", "bad-key")
    monkeypatch.setenv("GEMINI_API_KEY", "gemini-key")
    
    # Mock xAI to fail with 400
    respx.post("https://api.x.ai/v1/chat/completions").mock(
        return_value=httpx.Response(400, json={"error": "Incorrect API key"})
    )
    # Mock Gemini to succeed with 200
    respx.post("https://generativelanguage.googleapis.com/v1beta/openai/chat/completions").mock(
        return_value=httpx.Response(200, json={
            "choices": [{"message": {"role": "assistant", "content": "Hello from Gemini!"}}]
        })
    )
    
    result = asyncio.run(call_llm_with_fallback([{"role": "user", "content": "hello"}]))
    assert result["content"] == "Hello from Gemini!"
    assert result["_provider"] == "gemini"


@respx.mock
def test_all_providers_fail_raises_502(monkeypatch):
    import pytest
    from fastapi import HTTPException
    monkeypatch.setenv("XAI_API_KEY", "key1")
    monkeypatch.setenv("GEMINI_API_KEY", "key2")
    
    respx.post("https://api.x.ai/v1/chat/completions").mock(
        return_value=httpx.Response(500, text="xAI Server Error")
    )
    respx.post("https://generativelanguage.googleapis.com/v1beta/openai/chat/completions").mock(
        return_value=httpx.Response(503, text="Gemini Unavailable")
    )
    
    with pytest.raises(HTTPException) as exc_info:
        asyncio.run(call_llm_with_fallback([{"role": "user", "content": "hello"}]))
    assert exc_info.value.status_code == 502
    assert "xai" in exc_info.value.detail
    assert "gemini" in exc_info.value.detail
