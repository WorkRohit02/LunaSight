"""Schema check for science-engine output files.
Usage: python validate_outputs.py horizon file.json | ephemeris file.json | analysis file.json"""
import json, sys
from pydantic import ValidationError
from schemas import HorizonProfile, Ephemeris, SiteAnalysis

KINDS = {"horizon": HorizonProfile, "ephemeris": Ephemeris, "analysis": SiteAnalysis}

if __name__ == "__main__":
    if len(sys.argv) != 3 or sys.argv[1] not in KINDS:
        sys.exit(__doc__)
    try:
        KINDS[sys.argv[1]].model_validate(json.load(open(sys.argv[2])))
        print(f"OK: {sys.argv[2]} matches {sys.argv[1]} schema")
    except (ValidationError, json.JSONDecodeError) as e:
        print(f"FAIL: {sys.argv[2]}\n{e}")
        sys.exit(1)
