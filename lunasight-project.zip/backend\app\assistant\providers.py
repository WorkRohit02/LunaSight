import asyncio
import json
import logging
import os
from dataclasses import replace
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import httpx
from fastapi import HTTPException

from .tool_schemas import TOOL_SCHEMAS

logger = logging.getLogger("lunasight.providers")


@dataclass
class ProviderConfig:
    name: str
    base_url: str
    model: str
    api_key: Optional[str]
    timeout: float = 30.0


def get_providers() -> List[ProviderConfig]:
    """Returns the ordered list of AI providers to try."""
    providers: List[ProviderConfig] = []

    # 1. xAI / Grok
    xai_key = os.getenv("XAI_API_KEY")
    xai_base = os.getenv("XAI_BASE_URL", "https://api.x.ai/v1").rstrip("/")
    xai_model = os.getenv("XAI_MODEL", "grok-2-latest")
    providers.append(
        ProviderConfig(
            name="xai",
            base_url=f"{xai_base}/chat/completions",
            model=xai_model,
            api_key=xai_key.strip() if xai_key else None,
        )
    )

    # 2. Google Gemini (via official OpenAI-compatible endpoint)
    gemini_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    gemini_base = os.getenv("GEMINI_BASE_URL", "https://generativelanguage.googleapis.com/v1beta/openai").rstrip("/")
    gemini_model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
    providers.append(
        ProviderConfig(
            name="gemini",
            base_url=f"{gemini_base}/chat/completions",
            model=gemini_model,
            api_key=gemini_key.strip() if gemini_key else None,
        )
    )

    # 3. OpenAI
    openai_key = os.getenv("OPENAI_API_KEY")
    openai_base = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
    openai_model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    providers.append(
        ProviderConfig(
            name="openai",
            base_url=f"{openai_base}/chat/completions",
            model=openai_model,
            api_key=openai_key.strip() if openai_key else None,
        )
    )

    # 4. Groq
    groq_key = os.getenv("GROQ_API_KEY")
    groq_base = os.getenv("GROQ_BASE_URL", "https://api.groq.com/openai/v1").rstrip("/")
    groq_model = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
    providers.append(
        ProviderConfig(
            name="groq",
            base_url=f"{groq_base}/chat/completions",
            model=groq_model,
            api_key=groq_key.strip() if groq_key else None,
        )
    )

    # Allow custom reordering via LLM_PROVIDER_ORDER=gemini,xai,openai
    order_env = os.getenv("LLM_PROVIDER_ORDER")
    if order_env:
        order = [p.strip().lower() for p in order_env.split(",") if p.strip()]
        prov_map = {p.name: p for p in providers}
        ordered = []
        for name in order:
            if name in prov_map:
                ordered.append(prov_map.pop(name))
        ordered.extend(prov_map.values())
        providers = ordered

    return providers


async def call_single_provider(
    provider: ProviderConfig, messages: List[dict], allow_tools: bool = True
) -> dict:
    """Calls an individual OpenAI-compatible provider."""
    if not provider.api_key:
        raise ValueError(f"API key for '{provider.name}' is not set.")

    body: Dict[str, Any] = {
        "model": provider.model,
        "messages": messages,
        "temperature": 0.2,
    }
    if allow_tools:
        body["tools"] = TOOL_SCHEMAS
        body["tool_choice"] = "auto"

    headers = {
        "Authorization": f"Bearer {provider.api_key}",
        "Content-Type": "application/json",
    }

    async with httpx.AsyncClient(timeout=provider.timeout) as client:
        resp = await client.post(provider.base_url, json=body, headers=headers)
        resp.raise_for_status()
        data = resp.json()
        message = data["choices"][0]["message"]
        # Attach provider name for transparency
        message["_provider"] = provider.name
        return message


RETRY_STATUSES = {429, 500, 502, 503, 504}


async def call_with_retry(provider: ProviderConfig, messages: List[dict], allow_tools: bool = True) -> dict:
    """Retry temporary failures (overload, rate limit, network) a few times with a short wait.
    Env: LLM_MAX_ATTEMPTS (default 3), LLM_RETRY_DELAY seconds (default 1.5, doubles each retry)."""
    attempts = int(os.getenv("LLM_MAX_ATTEMPTS", "3"))
    delay = float(os.getenv("LLM_RETRY_DELAY", "1.5"))
    for n in range(1, attempts + 1):
        try:
            return await call_single_provider(provider, messages, allow_tools)
        except Exception as e:
            # Retry overload/rate-limit replies and dropped connections, but not timeouts (they are already slow)
            temporary = (
                isinstance(e, httpx.RequestError) and not isinstance(e, httpx.TimeoutException)
            ) or (isinstance(e, httpx.HTTPStatusError) and e.response.status_code in RETRY_STATUSES)
            if not temporary or n == attempts:
                raise
            print(f"[LLM Retry] {provider.name}/{provider.model} attempt {n} failed, retrying in {delay:.1f}s")
            await asyncio.sleep(delay)
            delay *= 2


def model_candidates(provider: ProviderConfig) -> List[ProviderConfig]:
    """The configured model first, then optional backups, e.g. GEMINI_FALLBACK_MODELS=model-a,model-b"""
    extra = os.getenv(f"{provider.name.upper()}_FALLBACK_MODELS", "")
    models = [provider.model] + [m.strip() for m in extra.split(",") if m.strip() and m.strip() != provider.model]
    return [replace(provider, model=m) for m in models]


async def call_llm_with_fallback(
    messages: List[dict], allow_tools: bool = True
) -> dict:
    """Tries configured AI providers in sequence. Switches to fallback if any fails."""
    providers = get_providers()
    configured = [p for p in providers if p.api_key]

    if not configured:
        raise HTTPException(
            status_code=500,
            detail="No AI provider configured. Set XAI_API_KEY, GEMINI_API_KEY, or OPENAI_API_KEY in backend/.env.",
        )

    errors = []
    for i, provider in enumerate(configured):
        next_provider_name = configured[i + 1].name if i + 1 < len(configured) else None
        try:
            msg = None
            last_exc: Exception = RuntimeError("no model tried")
            for candidate in model_candidates(provider):
                print(f"[LLM] Trying provider: {candidate.name} (model: {candidate.model})")
                try:
                    msg = await call_with_retry(candidate, messages, allow_tools)
                    break
                except Exception as model_exc:
                    last_exc = model_exc
                    print(f"[LLM] Model {candidate.model} failed, trying next model if any.")
            if msg is None:
                raise last_exc
            print(f"[LLM] Success with provider: {provider.name}")
            return msg
        except Exception as e:
            err_msg = ""
            if isinstance(e, httpx.HTTPStatusError):
                status = e.response.status_code
                text = e.response.text[:200]
                err_msg = f"HTTP {status}: {text}"
            elif isinstance(e, httpx.RequestError):
                kind = type(e).__name__
                err_msg = f"Network error: {kind}" + (" (no reply within the time limit)" if isinstance(e, httpx.TimeoutException) else f": {e}")
            else:
                err_msg = str(e)

            errors.append(f"{provider.name} ({err_msg})")
            fallback_note = f" Switching to fallback '{next_provider_name}'..." if next_provider_name else " No more fallbacks."
            print(f"[LLM Failover] Provider '{provider.name}' failed: {err_msg}.{fallback_note}")

    # If all configured providers failed
    detail_msg = f"All AI providers failed: {'; '.join(errors)}"
    raise HTTPException(status_code=502, detail=detail_msg)
