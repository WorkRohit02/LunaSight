"""The three tools the model can call. Each returns a JSON-serialisable dict and never raises."""
from datetime import datetime, timedelta, timezone
from typing import Optional

from pydantic import BaseModel, Field, ValidationError, field_validator, model_validator

from ..clients import science_client as sc
from . import docs_search

ALLOWED_DELAYS = (1.0, 7.0, 29.5)
METRICS = ("sunlit_hours", "longest_darkness_hours", "earth_visible_hours", "longest_blackout_hours")


def _parse_utc(value: str) -> datetime:
    s = value.strip()
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    dt = datetime.fromisoformat(s)
    if dt.tzinfo is None:
        raise ValueError("timestamp must include a timezone, for example 2027-01-15T00:00:00Z")
    return dt.astimezone(timezone.utc)


def _iso(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


class _Location(BaseModel):
    site_name: Optional[str] = None
    latitude: Optional[float] = Field(None, ge=-90, le=90)
    longitude: Optional[float] = Field(None, ge=-180, le=180)

    @model_validator(mode="after")
    def _need_location(self):
        has_coords = self.latitude is not None and self.longitude is not None
        if not self.site_name and not has_coords:
            raise ValueError("provide site_name, or both latitude and longitude")
        return self

    def label(self) -> str:
        return self.site_name or f"{self.latitude}, {self.longitude}"


class SiteAnalysisInput(_Location):
    start_time: str
    duration_hours: float = Field(24, gt=0, le=720)

    @field_validator("start_time")
    @classmethod
    def _t(cls, v):
        _parse_utc(v)
        return v


class DelayScenarioInput(_Location):
    original_start_time: str
    delay_days: float
    duration_hours: float = Field(24, gt=0, le=720)

    @field_validator("original_start_time")
    @classmethod
    def _t(cls, v):
        _parse_utc(v)
        return v

    @field_validator("delay_days")
    @classmethod
    def _d(cls, v):
        if float(v) not in ALLOWED_DELAYS:
            raise ValueError("delay_days must be 1, 7, or 29.5 (one lunar cycle)")
        return float(v)


class DocsInput(BaseModel):
    query: str = Field(min_length=1)


def _errors(e: ValidationError) -> str:
    return "; ".join(f"{'.'.join(str(x) for x in err['loc'])}: {err['msg']}" for err in e.errors())


async def _analyse(loc: _Location, start: datetime, hours: float) -> dict:
    payload = sc.build_payload(loc.site_name, loc.latitude, loc.longitude, _iso(start), hours)
    result = await sc.full_analysis(payload)
    return {"site": loc.label(), "start_time": _iso(start), "duration_hours": hours, **result, "estimate": True}


async def get_site_analysis(**kwargs) -> dict:
    try:
        a = SiteAnalysisInput(**kwargs)
        return await _analyse(a, _parse_utc(a.start_time), a.duration_hours)
    except ValidationError as e:
        return {"error": _errors(e)}
    except (sc.ScienceEngineError, ValueError) as e:
        return {"error": str(e)}


def _diff(new, old):
    return None if new is None or old is None else round(new - old, 6)


async def run_delay_scenario(**kwargs) -> dict:
    try:
        a = DelayScenarioInput(**kwargs)
        start = _parse_utc(a.original_start_time)
        original = await _analyse(a, start, a.duration_hours)
        delayed = await _analyse(a, start + timedelta(days=a.delay_days), a.duration_hours)
        changes = {f"change_{m}": _diff(delayed.get(m), original.get(m)) for m in METRICS}
        return {"delay_days": a.delay_days, "original": original, "delayed": delayed,
                "differences": changes, "estimate": True}
    except ValidationError as e:
        return {"error": _errors(e)}
    except (sc.ScienceEngineError, ValueError) as e:
        return {"error": str(e)}


async def search_docs(**kwargs) -> dict:
    try:
        a = DocsInput(**kwargs)
    except ValidationError as e:
        return {"error": _errors(e)}
    results = docs_search.search(a.query)
    if not results:
        return {"results": [], "note": "No matching passages found in the project documents."}
    return {"results": results}


TOOLS = {
    "get_site_analysis": get_site_analysis,
    "run_delay_scenario": run_delay_scenario,
    "search_docs": search_docs,
}


async def run_tool(name: str, arguments: dict) -> dict:
    fn = TOOLS.get(name)
    if fn is None:
        return {"error": f"Unknown tool: {name}"}
    if not isinstance(arguments, dict):
        return {"error": "Tool arguments must be a JSON object."}
    try:
        return await fn(**arguments)
    except TypeError as e:
        return {"error": f"Bad arguments for {name}: {e}"}
    except Exception as e:  # last-resort guard so the model can explain the failure
        return {"error": f"{name} failed: {type(e).__name__}"}
