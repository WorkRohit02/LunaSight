"""HTTP client for the existing science engine (black box).

Nothing is calculated here. We send a request to POST /analysis/full and map the
fields of the response to the names the assistant uses.

ASSUMPTION: the engine's request and response field names are not documented in
the brief. Adjust build_payload() and FIELD_MAP below if they differ.
"""
import os

import httpx


class ScienceEngineError(Exception):
    pass


# assistant field name -> key in the engine response
FIELD_MAP = {
    "sunlit_hours": "sunlit_hours",
    "longest_darkness_hours": "longest_darkness_hours",
    "earth_visible_hours": "earth_visible_hours",
    "longest_blackout_hours": "longest_blackout_hours",
}


def base_url() -> str:
    return os.getenv("SCIENCE_ENGINE_URL", "http://localhost:8001").rstrip("/")


def build_payload(site_name, latitude, longitude, start_time, duration_hours) -> dict:
    payload = {"start_time": start_time, "duration_hours": duration_hours}
    if site_name:
        payload["site_name"] = site_name
    if latitude is not None and longitude is not None:
        payload["latitude"] = latitude
        payload["longitude"] = longitude
    return payload


async def full_analysis(payload: dict) -> dict:
    # Default: call the engine inside this same server. Set USE_EXTERNAL_ENGINE=1 to use SCIENCE_ENGINE_URL instead.
    if os.getenv("USE_EXTERNAL_ENGINE") != "1":
        import engine_api
        try:
            return normalize(engine_api.full_analysis(payload))
        except (ValueError, KeyError) as e:
            raise ScienceEngineError(str(e))
    url = f"{base_url()}/analysis/full"
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(url, json=payload)
            resp.raise_for_status()
            raw = resp.json()
    except httpx.HTTPStatusError as e:
        raise ScienceEngineError(
            f"Science engine returned HTTP {e.response.status_code}: {e.response.text[:200]}"
        )
    except httpx.RequestError as e:
        raise ScienceEngineError(
            f"Could not reach the science engine at {base_url()} ({type(e).__name__})."
        )
    except ValueError:
        raise ScienceEngineError("Science engine returned a response that is not valid JSON.")
    return normalize(raw)


def normalize(raw: dict) -> dict:
    if not isinstance(raw, dict):
        raise ScienceEngineError("Science engine returned an unexpected response shape.")
    out = {name: raw.get(key) for name, key in FIELD_MAP.items()}
    if all(v is None for v in out.values()):
        raise ScienceEngineError(
            "Science engine response did not contain the expected fields: "
            + ", ".join(FIELD_MAP.values())
        )
    missing = [n for n, v in out.items() if v is None]
    if missing:
        out["not_returned_by_engine"] = missing
    return out
