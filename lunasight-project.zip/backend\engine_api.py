"""Adapter between the assistant's /analysis/full request and the engine behind this API.
Swap mock_data for the real science engine here, in one place."""
import math
from datetime import datetime
from pydantic import ValidationError
import mock_data as engine
from schemas import AnalyzeRequest


def _norm(s: str) -> str:
    return "".join(c for c in s.lower() if c.isalnum())


def _match_site(name: str):
    n = _norm(name)
    for s in engine.PRESET_SITES:
        if n in (_norm(s.id), _norm(s.name)):
            return s
    return None


def full_analysis(payload: dict) -> dict:
    """payload: site_name | latitude+longitude, start_time (ISO UTC), duration_hours.
    Returns the four headline metrics (plus an estimate flag)."""
    start = datetime.fromisoformat(str(payload["start_time"]).replace("Z", "+00:00"))
    days = max(1, math.ceil(float(payload.get("duration_hours", 24)) / 24))
    kwargs = {"start_date": start.strftime("%Y-%m-%d"), "days": min(days, 60)}
    site = _match_site(payload["site_name"]) if payload.get("site_name") else None
    if site:
        kwargs["site_id"] = site.id
    elif payload.get("latitude") is not None and payload.get("longitude") is not None:
        kwargs.update(lat=payload["latitude"], lon=payload["longitude"])
    else:
        raise ValueError(f"Unknown site '{payload.get('site_name')}'. Use a preset site or latitude+longitude.")
    try:
        res = engine.mock_analysis(AnalyzeRequest(**kwargs))
    except ValidationError as e:
        raise ValueError(f"Invalid input: {e.errors()[0]['msg']}")
    s = res.summary
    return {"sunlit_hours": s.sunlit_hours, "longest_darkness_hours": s.longest_darkness_hours,
            "earth_visible_hours": s.earth_visible_hours, "longest_blackout_hours": s.longest_blackout_hours,
            "solar_power_wh_per_m2": s.solar_power_wh_per_m2, "is_estimate": True}
