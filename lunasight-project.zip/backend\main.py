"""One server for everything.  Run: uvicorn main:app --reload --port 3000
Docs: http://localhost:3000/docs"""
from dotenv import load_dotenv
from fastapi import APIRouter, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

load_dotenv()

from schemas import *
import mock_data as engine  # swap for the real science engine later
import engine_api
from app.assistant.chat import router as chat_router

app = FastAPI(title="LunaSight API", version=SCHEMA_VERSION)
api = APIRouter(prefix="/api")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

DELAY_DAYS = {"+1 day": 1, "+7 days": 7, "+1 lunar cycle": engine.LUNAR_CYCLE_DAYS}
METRICS = ["sunlit_hours", "longest_darkness_hours", "earth_visible_hours",
           "longest_blackout_hours", "solar_power_wh_per_m2"]


def run(req: AnalyzeRequest, shift=0):
    try:
        return engine.mock_analysis(req, shift)
    except (KeyError, ValueError) as e:
        raise HTTPException(400, f"Bad site or input: {e}")


@api.get("/health")
def health():
    return {"status": "ok", "schema_version": SCHEMA_VERSION}


@api.get("/sites", response_model=list[Site])
def sites():
    return engine.PRESET_SITES


@api.post("/analyze", response_model=SiteAnalysis)
def analyze(req: AnalyzeRequest):
    return run(req)


@api.post("/scenario", response_model=ScenarioResult)
def scenario(req: ScenarioRequest):
    base, delayed = run(req.base), run(req.base, DELAY_DAYS[req.delay])
    changes = {m: round(getattr(delayed.summary, m) - getattr(base.summary, m), 2) for m in METRICS}
    return ScenarioResult(delay=req.delay, baseline=base, delayed=delayed, changes=changes)


@api.post("/compare", response_model=CompareResult)
def compare(req: CompareRequest):
    return CompareResult(results=[run(s) for s in req.scenarios])


# Same engine in the shape the assistant's science client expects
@app.post("/analysis/full")
@api.post("/analysis/full")
def analysis_full(payload: dict):
    try:
        return engine_api.full_analysis(payload)
    except (ValueError, KeyError) as e:
        raise HTTPException(400, str(e))


app.include_router(api)
app.include_router(chat_router, prefix="/api")  # POST /api/chat
